# spring-secrets-manager


https://viyaanj.medium.com/aws-secrets-manager-with-spring-boot-e198f876a107
