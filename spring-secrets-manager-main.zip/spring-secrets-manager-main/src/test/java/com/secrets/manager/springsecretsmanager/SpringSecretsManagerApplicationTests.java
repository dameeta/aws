package com.secrets.manager.springsecretsmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecretsManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
